----------------
Distributed
----------------

The following pages describe the APIs used to easily perform communication
between different processes in CuPy.


.. module:: cupyx.distributed

.. autosummary::
   :toctree: generated/

   init_process_group
   NCCLBackend
