:orphan:

This document has been moved to :doc:`scipy_fftpack`.
