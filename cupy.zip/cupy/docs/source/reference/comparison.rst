Comparison Table
================

Here is a list of NumPy / SciPy APIs and its corresponding CuPy implementations.

``-`` in CuPy column denotes that CuPy implementation is not provided yet.
We welcome contributions for these functions.

.. include:: comparison_table.rst.inc
