Padding arrays
==============

.. Hint:: `NumPy API Reference: Padding arrays <https://numpy.org/doc/stable/reference/routines.padding.html>`_

.. currentmodule:: cupy
.. autosummary::
   :toctree: generated/

   pad
