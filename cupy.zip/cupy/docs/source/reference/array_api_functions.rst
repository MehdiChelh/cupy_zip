Array API Functions
===================

This section is a full list of implemented APIs. For the detailed documentation, see the
`array API specification <https://data-apis.org/array-api/latest/API_specification/index.html>`_.

.. automodule:: cupy.array_api
   :members:
