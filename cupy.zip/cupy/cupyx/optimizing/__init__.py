from cupyx.optimizing._optimize import optimize  # NOQA
