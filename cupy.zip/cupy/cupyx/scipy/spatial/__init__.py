from cupyx.scipy.spatial.distance import distance_matrix   # NOQA
