# CuPy ROCm Docker Image

```
docker run -it --device=/dev/kfd --device=/dev/dri --group-add video cupy/cupy-rocm
```
