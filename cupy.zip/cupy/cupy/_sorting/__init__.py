# Functions from the following NumPy document
# https://numpy.org/doc/stable/reference/routines.sort.html
