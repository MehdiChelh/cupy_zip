from cupy_backends.cuda.libs.profiler import *  # NOQA
